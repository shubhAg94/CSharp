﻿namespace DesignPatternsInCSharp.Adapter.AdapterIntroduction
{
    public enum CharacterSource
    {
        File,
        Api
    }
}
