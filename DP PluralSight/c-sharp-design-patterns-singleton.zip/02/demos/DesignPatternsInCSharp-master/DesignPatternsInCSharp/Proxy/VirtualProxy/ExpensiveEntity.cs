﻿namespace DesignPatternsInCSharp.Proxy.VirtualProxy
{
    public class ExpensiveEntity
    {
        public int Id { get; set; }
    }
}