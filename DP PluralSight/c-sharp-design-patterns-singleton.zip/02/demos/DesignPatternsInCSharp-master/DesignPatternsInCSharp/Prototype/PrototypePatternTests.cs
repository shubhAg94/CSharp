using System;
using Xunit;

namespace DesignPatternsInCSharp
{
}
