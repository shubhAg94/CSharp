﻿namespace Factory_Pattern_in_Testing.Business.Models.Commerce
{
    public enum PaymentProvider
    {
        Paypal,
        CreditCard,
        Invoice
    }
}