﻿using Adding_a_Factory_Provider.Business.Models.Commerce;

namespace Adding_a_Factory_Provider.Business.Models.Shipping
{
    public class GlobalExpressShippingProvider : ShippingProvider
    {
        public override string GenerateShippingLabelFor(Order order)
        {
            return "GLOBAL-EXPRESS";
        }
    }
}
