﻿namespace Adding_a_Factory_Provider.Business.Models.Commerce
{
    public enum PaymentProvider
    {
        Paypal,
        CreditCard,
        Invoice
    }
}