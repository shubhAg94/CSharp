﻿namespace Factory_Pattern_First_Look.Business.Models.Commerce
{
    public enum PaymentProvider
    {
        Paypal,
        CreditCard,
        Invoice
    }
}