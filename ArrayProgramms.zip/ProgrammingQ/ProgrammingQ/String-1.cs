﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingQ
{
    public class String_1
    {
        public static string InputString()
        {
            Console.WriteLine("Enter String");
            string str = Console.ReadLine();

            Console.WriteLine("================================================");
            return str;
        }

        public static string SwapCharacters (string str, int i, int j)
        {
            char temp;
            char[] charArray = str.ToCharArray();
            temp = charArray[i];
            charArray[i] = charArray[j];
            charArray[j] = temp;
            string s = new string(charArray);
            return s;
        }

        public static void Print_Permutations()
        {
            string str = InputString();
            Permute(str, 0, str.Length - 1);
        }

        public static void Permute(string str, int left, int right)
        {
            if (left == right)
                Console.WriteLine(str);
            else
            {
                for (int i = left; i <= right; i++)
                {
                    str = SwapCharacters(str, left, i);
                    Permute(str, left + 1, right);
                    str = SwapCharacters(str, left, i);
                }
            }
        }
    }
}
